# Flask-MongoDB Web App

In this assignment you will create a web app that relies upon a MongoDB database.

Replace the contents of this file with a description of your own web app, as described in [the instructions](./instructions.md).
